import React, { useState, useEffect } from 'react';
import { Link } from 'react-router-dom';
import './Hero.css';

const Hero = () => {
  const [books, setBooks] = useState([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState(null);

  useEffect(() => {
    fetchBooks();
  }, []);

  const fetchBooks = async () => {
    try {
      const response = await fetch('https://lavina.onrender.com/books');
      if (response.ok) {
        const result = await response.json();
        console.log("Fetched data:", result);

        if (result.isOk && Array.isArray(result.data)) {
          setBooks(result.data);
        } else {
          setError('Unexpected data format');
          console.error('Unexpected data format:', result);
        }
      } else {
        setError('Failed to fetch books');
      }
    } catch (err) {
      setError('Network error occurred');
      console.error('Error fetching books:', err);
    } finally {
      setLoading(false);
    }
  };

  const getStatusBadge = (status) => {
    const statusClasses = {
      'New': 'status-new',
      'Reading': 'status-reading', 
      'Finished': 'status-finished'
    };
    return statusClasses[status] || 'status-default';
  };

  if (loading) {
    return (
      <div className="hero-container">
        <div className="loading">Loading books...</div>
      </div>
    );
  }

  if (error) {
    return (
      <div className="hero-container">
        <div className="error">Error: {error}</div>
      </div>
    );
  }

  return (
    <div className="hero-container">
      <header className="hero-header">
        <div className="header-left">
          <div className="logo">
            <span className="logo-icon">✓</span>
            <span className="logo-text">Books</span>
            <span className="logo-list">List</span>
          </div>
          <div className="search-container">
            <input 
              type="text" 
              placeholder="Search for any training you want"
              className="search-input"
            />
          </div>
        </div>
        <div className="header-right">
          <div className="profile-avatar">A</div>
        </div>
      </header>

      <main className="hero-main">
        <div className="hero-title-section">
          <h1 className="hero-title">
            You've got <span className="title-number">{books.length}</span> book{books.length !== 1 ? 's' : ''}
          </h1>
          <p className="hero-subtitle">Your books today</p>
          <button className="create-book-btn">+ Create a book</button>
        </div>

        <div className="books-grid">
          {books.map((book, index) => (
            <div key={book.id || index} className="book-card">
              <h3 className="book-title">{book.title || 'Raspberry Pi User Guide'}</h3>
              <p className="book-cover">Cover: <a href={book.coverUrl || '#'} className="book-link">http://url.to.book.cover</a></p>
              <p className="book-pages">Pages: {book.pages || '221'}</p>
              <p className="book-published">Published: {book.published || '2012'}</p>
              <p className="book-isbn">Isbn: {book.isbn || '9781118464465'}</p>
              <div className="book-footer">
                <span className="book-author">{book.author || 'Eben Upton'} / {book.year || '2012'}</span>
                <span className={`book-status ${getStatusBadge(book.status || 'New')}`}>
                  {book.status || 'New'}
                </span>
              </div>
            </div>
          ))}
        </div>

        <div className="floating-actions">
          <button className="action-btn delete-btn">Delete</button>
          <button className="action-btn edit-btn">Edit</button>
        </div>
      </main>
    </div>
  );
};

export default Hero;
